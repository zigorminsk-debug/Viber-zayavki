package by.viberlead.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import org.json.JSONObject;

import java.util.List;

/** История отправленных заявок: статус, текст, копирование и повторная отправка в Viber. */
public class HistoryActivity extends Activity {

    private Settings settings;
    private LinearLayout container;
    private TextView tvEmpty;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_history);
        settings = new Settings(this);
        container = findViewById(R.id.history_container);
        tvEmpty = findViewById(R.id.tv_empty);

        Button btnBack = findViewById(R.id.btn_back);
        Button btnClear = findViewById(R.id.btn_clear);
        btnBack.setOnClickListener(v -> finish());
        btnClear.setOnClickListener(v -> new AlertDialog.Builder(this)
                .setTitle(R.string.btn_clear)
                .setMessage("Удалить все записи истории?")
                .setPositiveButton("Удалить", (d, w) -> {
                    settings.clearHistory();
                    render();
                })
                .setNegativeButton(R.string.cancel, null)
                .show());

        render();
    }

    @Override
    protected void onResume() {
        super.onResume();
        render();
    }

    private void render() {
        container.removeAllViews();
        List<JSONObject> items = settings.getHistory();
        tvEmpty.setVisibility(items.isEmpty() ? View.VISIBLE : View.GONE);

        LayoutInflater inflater = LayoutInflater.from(this);
        for (JSONObject o : items) {
            View v = inflater.inflate(R.layout.item_history, container, false);
            final String text = o.optString("text", "");
            final String status = o.optString("status", Settings.STATUS_OK);

            TextView date = v.findViewById(R.id.item_date);
            TextView st = v.findViewById(R.id.item_status);
            TextView name = v.findViewById(R.id.item_name);
            TextView body = v.findViewById(R.id.item_text);
            Button copy = v.findViewById(R.id.item_copy);
            Button resend = v.findViewById(R.id.item_resend);

            date.setText(o.optString("date", "—") + "  ·  " + o.optString("detail", ""));
            name.setText(o.optString("name", "Заявка"));
            body.setText(text);

            if (Settings.STATUS_OK.equals(status)) {
                st.setText(R.string.st_ok);
                st.setBackgroundResource(R.drawable.bg_chip_ok);
                st.setTextColor(getResources().getColor(R.color.success));
            } else if (Settings.STATUS_MANUAL.equals(status)) {
                st.setText(R.string.st_manual);
                st.setBackgroundResource(R.drawable.bg_chip_ok);
                st.setTextColor(getResources().getColor(R.color.viber_purple_dark));
            } else {
                st.setText(R.string.st_err);
                st.setBackgroundResource(R.drawable.bg_chip_err);
                st.setTextColor(getResources().getColor(R.color.error));
            }

            copy.setOnClickListener(x -> MainActivity.copyToClipboard(this, text));
            resend.setOnClickListener(x -> MainActivity.openExternal(this, text));
            v.setOnClickListener(x -> new AlertDialog.Builder(this)
                    .setTitle(o.optString("name", "Заявка"))
                    .setMessage(text)
                    .setPositiveButton(R.string.btn_copy, (d, w) -> MainActivity.copyToClipboard(this, text))
                    .setNegativeButton(R.string.btn_open_viber, (d, w) -> MainActivity.openExternal(this, text))
                    .setNeutralButton(R.string.close, null)
                    .show());

            container.addView(v);
        }
    }
}
